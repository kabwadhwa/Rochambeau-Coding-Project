# Functions for a simple spinner/rock-paper-scissors game

def determine_winner(choices):
    """
    This function takes two choices from rock-paper-scissors
    and returns the result.
    """
    players = list(choices.keys())

    if choices[players[0]]== "rock":
        if(choices[players[1]] == "rock"):
            winning_player = None
        elif(choices[players[1]] == "paper"):
            winning_player = players[1]
        elif(choices[players[1]] == "scissors"):
            winning_player = players[0]
    elif choices[players[0]] == "paper":
        if choices[players[1]] == "rock":
            winning_player = players[0]
        elif choices[players[1]] == "paper":
            winning_player = None
        elif choices[players[1]] == "scissors":
            winning_player = players[0]
    elif choices[players[0]] == "scissors":
        if choices[players[1]] == "rock":
            winning_player = players[1]
        elif choices[players[1]] == "paper":
            winning_player = players[0]
        elif choices[players[1]] =="scissors":
            winning_player = None
    else:
        raise ValueError("Oops, that doesn't work. Please choose rock, paper or scissors!")


    if winning_player is None:
        results = "tie"
        winning_choice = None
    else:
        winning_choice = choices[winning_player]
        results = f"{winning_player} won with {winning_choice}!"
        

    print(results)
    return winning_player, winning_choice

